# Hostbill Proxy

A proxy for the Hostbill API that adds security and session mangement to allow for use in published apps.

## Dependencies

- Node.js

## Getting Started

## Starting the server

npm start

The proxy acts like a middleware between the app and Hostbill. The proxy is run as a server and provides a RESTful API. It parses data, manage sessions and reroute connections to the Hostbill API.

1. Setup the `config.json` and enter your **API Key**, **API ID** and **Endpoint URI** (without leading slash)

        {
            "server": {
                "port": 1337 // Set port for the server to listen on
            },

            "hostbill": {
                "api_key": "<API_KEY>", // Your Hostbill API key
                "api_id": "<API_ID>", // Your Hostbill API id
                "api_endpoint": "<API_ENDPOINT>" // Your Hostbill API endpoint
            }
        }

2. Run the server `npm start`.
   **NOTE:** Run the server with `forever` to automatically start the server if the server should shutdown.

## Why?

The Hostbill API is an internal system and their API is not secure enough to be used in published environments, since all client information can be modified without proper authentication.

The proxy manages sessions on its own and is seperated from the Hostbill API. The proxy also implements a seperate REST API which routes to the Hostbill API, but requires sessions to retrieve client information.

## API

### Clients

#### Verify Client Login

    GET /client/verify

###### Response

    HTTP/1.1 200 OK
    Content-Type: application/json
    Content-Length: 33
    Connection: keep-alive

    {"success":true,"client_id":"54"}
