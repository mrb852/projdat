var config = require('./config'),
    server = require('./src/server').run(config.server.port);
