var Hostbill = require('../lib/hostbill'),
    config = require('./config');

module.exports = Hostbill({
    api_key: config.hostbill.api_key,
    api_id: config.hostbill.api_id,
    api_endpoint: config.hostbill.api_endpoint
});
