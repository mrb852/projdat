//require("daemon")(); // use https://github.com/nodejitsu/forever
var express = require("express");
var http = require("http");
var cookieParser = require("cookie-parser");
var session = require("express-session");
var app = express();
var apiKey = "010928a35be31506aef3";
var apiID = "476b254276b246dd0687";
var apiURL = "http://127.0.0.1/surf-admin/api.php?api_id="+apiID+"&api_key="+apiKey+"&call=";

app.use(cookieParser());
app.use(session({
    secret: 'ThisIsAVerySecretKey_qmr656',
    key: 'Surftown_api_session'
}));

var billhostOptions = {
  hostname: '127.0.0.1',
  port: 80,
  method: 'GET'
};

var forbiddenParams = [
    "id"
];

var clientFunctions = [
    "getClientDetails",
    "getClientOrders",
    "getClientStats",
    "getClientAccounts",
    "getClientTransactions",
    "getClientInvoices",
    "getClientDomains",
    "getClientEmails",
    "getClientTickets",
    "setClientDetails",
    "editClientCreditCard",
    "verifyClientLogin"
];

app.get("/login/email/:email/password/:password", function(req, res){
    http.get(apiURL+"verifyClientLogin&email="+encodeURIComponent(req.params.email)
             +"&password="+encodeURIComponent(req.params.password), function(resp){
         resp.setEncoding("utf8");
         resp.on("data", function(data){
            data = JSON.parse(data);
            if(!data.success){
                req.session.destroy();
                res.send(403, "wrong");
                return;
            }
            req.session.clientID = data.client_id;
            res.send(200, "correct");
        });
    }).on("error", error);
});

app.get("/client/:func", function(req, res){
    if(!req.session.clientID || !checkFunction(req, clientFunctions)){
        res.send(403, "Access denied");
        return;
    }

    http.get(createURL(req), function(resp){
        resp.setEncoding("utf8");
        resp.on("data", function(data){
            res.send(data);
        });
    }).on("error", error);
});

function checkFunction(req, functions){
    for(var i = 0; i < functions.length; i++)
        if(functions[i] == req.params.func)
            return true;
    return false;
}

function createURL(req){
    var url = apiURL+req.params.func+"&id="+req.session.clientID;
    params = filterParams(req.params);
    for(var i in params)
        url += "&"+i+"="+params[i];
    return url;
}

function filterParams(params){
    var legalParams = {};
    for(var p in params){
        var param = params[p];
        var forbidden = false;
        for(var i = 0; i < forbiddenParams.length; i++){
            if(param == forbiddenParams[i]){
                forbidden = true;
                break;
            }
        }
        if(!forbidden)
            legalParams[p] = param;
    }
    return legalParams;
}

function error(e){
    console.log(e);
    res.send(e.message);
}

app.listen(8585);
