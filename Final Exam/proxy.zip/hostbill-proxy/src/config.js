var nconf = require('nconf'),
    path = require('path'),
    colors = require('colors');

try {
    nconf.use('file', { 'file': path.join(path.dirname(require.main.filename) + '/config.json') });
    nconf.load();
} catch (e) {
    console.error(e.message.red);
}

exports.hostbill = nconf.get('hostbill');
exports.server = nconf.get('server');
