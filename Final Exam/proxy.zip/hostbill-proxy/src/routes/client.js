var hostbill = require('../hostbill'),
    auth = require('basic-auth');

/**
 * Get client credentials
 *
 * getClientDetails
 */
exports.get = function(req, res) {
    hostbill.get('getClientDetails', { id: req.session.clientId }, function (err, response, body) {
        if(err) console.error(err);
        res.send(200, body);
    });
};

/**
 * Edit client credentials
 *
 * setClientDetails
 */
exports.edit = function(req, res) {
    /*hostbill.put('setClientDetails', { id: req.session.clientId }, function (err, response, body) {
        res.send(200, body);
    });*/
};

/**
 * addClient
 */
exports.add = function(req, res) {

};

/**
 * Verify client login and sets a session upon success
 *
 * verifyClientLogin
 */
exports.verify = function(req, res) {
    var user = auth(req);

    var email = user.name,
        password = user.pass;

    if(!email || !password) {
        req.session.destroy();
        res.send(403, {
            success: false,
            message: "Couldn't verify client."
        });
        return;
    }

    hostbill.get('verifyClientLogin', {
        email: email,
        password: password
    }, function(err, response, body) {
        console.log(user, body, err);
        if(err) {
            req.session.destroy();
            res.send(500, {
                success: false,
                message: 'Connection Timeout'
            });
            return;
        }

        if(!body.success) {
            req.session.destroy();
            res.send(403, {
                success: false,
                message: "Couldn't verify client."
            });
            return;
        }

        // Set session client id
        req.session.clientId = body.client_id;
        res.send(200, {
            success: true,
            client_id: req.session.clientId
        });
    });
};

/**
 * getClientOrders
 */
exports.orders = function(req, res) {
    hostbill.get('getClientOrders', { id: req.session.clientId }, function (err, response, body) {
        if(err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientStats
 */
exports.stats = function(req, res) {
    hostbill.get('getClientStats', { id: req.session.clientId }, function (err, response, body) {
        if(err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientAccounts
 */
exports.accounts = function(req, res) {
    hostbill.get('getClientAccounts', { id: req.session.clientId }, function(err, response, body) {
        if (err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientTransactions
 */
exports.transactions = function(req, res) {
    hostbill.get('getClientTransactions', { id: req.session.clientId }, function(err, response, body) {
        if (err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientInvoices
 */
exports.invoices = function(req, res) {
    hostbill.get('getClientInvoices', { id: req.session.clientId }, function(err, response, body){
        if (err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientDomains
 */
exports.domains = function(req, res) {
    hostbill.get('getClientDomains', { id: req.session.clientId }, function(err, response, body){
        if (err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientEmails
 */
exports.emails = function(req, res) {
    hostbill.get('getClientEmails', { id: req.session.clientId }, function(err, response, body) {
        if (err) console.error(err);
        res.send(200, body);
    });
};

/**
 * getClientTickets
 */
exports.tickets = function(req, res) {
    hostbill.get('getClientTickets', { id: req.session.clientId }, function(err, response, body) {
        if (err) console.error(err);
        res.send(200, body);
    });
};
