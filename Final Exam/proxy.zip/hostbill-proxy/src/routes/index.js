var client = require('./client');

var requireAuthentication = function (req, res) {
    if(!req.session.clientId) {
        res.send(403, {
            success: false,
            message: "Not signed in, yet"
        });
        return;
    }
};

module.exports = function(app) {

    /**
     * Global routes
     * Requires client authentication for each request
     */
    //app.all('*', requireAuthentication);

    /**
     * Client routes
     * GET /client - Gets client credentials from session (auth required)
     * PUT /client - Sets client credentials from session (auth required)
     * POST /client - Add a new client
     * GET /client/:func - Gets other client info from session (auth required)
     */
    app.get('/client', client.get, requireAuthentication);
    app.put('/client', client.edit, requireAuthentication);

    app.post('/client', client.add);
    app.get('/client/verify', client.verify);

    app.get('/client/orders', client.orders, requireAuthentication);
    app.get('/client/stats', client.stats, requireAuthentication);
    app.get('/client/accounts', client.accounts, requireAuthentication);
    app.get('/client/transactions', client.transactions, requireAuthentication);
    app.get('/client/invoices', client.invoices, requireAuthentication);
    app.get('/client/domains', client.domains, requireAuthentication);
    app.get('/client/emails', client.emails, requireAuthentication);
    app.get('/client/tickets', client.tickets, requireAuthentication);
};
