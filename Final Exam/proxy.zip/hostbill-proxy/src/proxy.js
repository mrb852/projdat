var express = require('express'),
    session = require('express-session'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    qs = require('querystring'); // Routes witions

var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(session({
    secret: 'thisisveryphuckingsecretz_123981203821',
    key: 'surftown_api_session'
}));

var routes = require('./routes')(app);
app.listen(1337);
