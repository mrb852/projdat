var express = require('express'),
    app = express(),
    http = require('http');

    // Modules
var colors = require('colors'),
    winston = require('winston'),
    moment = require('moment');

    // Express Middleware
var session = require('express-session'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    expressWinston = require('express-winston');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(expressWinston.logger({
    transports: [
        new winston.transports.Console({
            json: false,
            colorize: true,
            timestamp: function() {
                return (moment().format('hh:mm:ss')).black;
            }
        })
    ],
    meta: false,
    msg: "{{res.statusCode}} " + "{{req.method}} ".yellow + "{{req.url}} - " + "{{res.responseTime}}ms".black
}));
app.use(session({
    secret: 'thisisveryphuckingsecretz_123981203821',
    key: 'surftown_api_session'
}));

var routes = require('./routes')(app);

// Error logging
app.use(expressWinston.errorLogger({
    transports: [
        new (winston.transports.Console)({
            json: true,
            colorize: true
        }),
        new (winston.transports.File)({
            filename: '../errors.log',
            handleExceptions: true
        })
    ]
}));

app.listen = function() {
    var server = http.createServer(this);
    return server.listen.apply(server, arguments);
};

exports.run = function(port) {
    if(port === null) port = 1337;
    app.listen(port, function() {
    console.log('Ready for connections.'.green);
    console.log('    http://%s:%s/',
        (this.address().address === '0.0.0.0') ? 'localhost' : this.address().address,
        this.address().port);
    });
};
