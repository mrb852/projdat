package com.eosol.surftownprototype;

import android.os.AsyncTask;
import android.util.Base64;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

import org.json.*;

public class SurftownConnector {
	private static final String serverUrl = "http://localhost:1337/";
	public void verify(final String username, final String password, Callback callback){
		class AsyncLogin extends MyAsyncTask<Void, Void> {
			
			public AsyncLogin(Callback cb) {
				super(cb);
			}

			@Override
			protected JSONObject doInBackground(Void... dummy) {
				try{
					HttpURLConnection con = SurftownConnector.this.createConnection("verify");
					String credentials = username + ":" + password;
					String auth = "Basic " + new String(Base64.encode(credentials.getBytes(), Base64.DEFAULT));
					con.setRequestProperty("Authorization", auth);
					BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
					this.responseCode = con.getResponseCode();
					String buffer = "";
					String line;
					while((line = in.readLine()) != null)
						buffer += line;
					return new JSONObject(buffer);
				}catch(IOException e){
					this.exception = e;
					this.exceptionType = "IOException";
				}catch(JSONException e){
					this.exception = e;
					this.exceptionType = "JSONException";
				}
				
				return null;
			}
		}
		AsyncLogin login = new AsyncLogin(callback);
		login.execute();
	}
	
	private HttpURLConnection createConnection(String url) throws IOException{
		URL oUrl = null;
		try{
			oUrl = new URL(SurftownConnector.serverUrl + url);
		}catch(MalformedURLException e){
			e.printStackTrace();
		}
		return (HttpURLConnection) oUrl.openConnection();
	}
	
	private abstract class MyAsyncTask<Params, Progress> extends AsyncTask<Params, Progress, JSONObject>{
		public Exception exception = null;
		public String exceptionType = null;
		private Callback callback = null;
		protected Integer responseCode = null;

		public MyAsyncTask(Callback cb){
			super();
			this.callback = cb;
		}
		
		protected void onPostExecute(JSONObject json){
			if(this.exception != null)
				this.callback.errorCallback(exception, exceptionType);
			else
				this.callback.successCallback(json, this.responseCode);
		}
	}
}
