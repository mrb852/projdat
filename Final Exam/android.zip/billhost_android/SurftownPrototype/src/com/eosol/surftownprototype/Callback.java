package com.eosol.surftownprototype;

import org.json.*;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

public abstract class Callback {
	private Activity parent = null;
	public Callback(Activity parent){
		this.parent = parent;
	}
	public Callback(){}
	//void errorCallback(Exception exception, Integer exceptionType);
	void errorCallback(Exception exception, String exceptionType){
		if(this.parent != null){
			Context context = this.parent.getApplicationContext();
			CharSequence message = null;
			if(exceptionType.equals("IOException"))
				message = context.getResources().getString(R.string.NetworkError);
			else if(exceptionType.equals("JSONException"))
				message = context.getResources().getString(R.string.ServerError);
			Toast toast = Toast.makeText(context, message, Toast.LENGTH_LONG);
			toast.show();
		}
	}
	//void successCallback(Surftown surftown);
	abstract void successCallback(JSONObject json, Integer responseCode);
}
