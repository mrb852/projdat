package com.eosol.surftownprototype;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class CategoryFragment extends Fragment {
	
	final static String FRAGMENT_LAYOUT = "layout_number";
	
    public CategoryFragment() {
    	
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        int i = getArguments().getInt(FRAGMENT_LAYOUT);
        View rootView = inflater.inflate(i, container, false);

        return rootView;
    }
}
