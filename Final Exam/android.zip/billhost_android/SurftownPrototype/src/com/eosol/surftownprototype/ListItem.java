package com.eosol.surftownprototype;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.eosol.surftownprototype.TwoTextArrayAdapter.RowType;

public class ListItem implements Item {
	private final String         str;

	public ListItem(String text) {
		this.str = text;
	}

	@Override
	public int getViewType() {
		return RowType.LIST_ITEM.ordinal();
	}

	@Override
	public View getView(LayoutInflater inflater, View convertView) {
		View view;
		if (convertView == null) {
			view = (View) inflater.inflate(R.layout.my_list_item, null);
			// Do some initialization
		} else {
			view = convertView;
		}

		TextView text = (TextView) view.findViewById(R.id.list_content);
		text.setText(str);

		return view;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public String getName() {
		return str;
	}

}
