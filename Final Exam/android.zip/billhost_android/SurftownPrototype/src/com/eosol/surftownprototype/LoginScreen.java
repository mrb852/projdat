package com.eosol.surftownprototype;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginScreen extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_screen);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	public void LoginClicked(View v){
		EditText mail = (EditText)findViewById(R.id.LoginScreenEditMail);
		EditText password = (EditText)findViewById(R.id.LoginScreenEditPassword);
		
		class LoginCallback extends Callback {
			@Override
			public void successCallback(JSONObject json, Integer responseCode) {
				try{
					if(json.getBoolean("success")){
						Intent intent = new Intent("com.eosol.surftownprototype.MainActivity");
						startActivity(intent);
					}else{
						CharSequence message = getResources().getString(R.string.WrongPassword);
						Toast toast = Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG);
						toast.show();
					}
				}catch(JSONException e){
					e.printStackTrace();
				}
			}
		}
		LoginCallback callback = new LoginCallback();
		SurftownConnector con = new SurftownConnector();
		con.verify(mail.getText().toString(), password.getText().toString(), callback);
	}
}
 