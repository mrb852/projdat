//
//  STDomainViewController.h
//  Surftown
//
//  Created by Simon Warg on 15/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STDomainViewController : UITableViewController

@end
