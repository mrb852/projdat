//
//  STHomeCell.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 18/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STHomeCell : UITableViewCell

@property (nonatomic, readonly) UILabel *iconLabel;
@property (nonatomic) CGFloat iconSize;
@property (nonatomic) NSString *icon;

@end
