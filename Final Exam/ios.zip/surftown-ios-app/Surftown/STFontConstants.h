//
//  STFontConstants.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 18/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#ifndef Surftown_STFontConstants_h
#define Surftown_STFontConstants_h

static NSString * const kGothamBlack = @"Gotham-Black";
static NSString * const kGothamBlackItalic = @"Gotham-BlackItalic";
static NSString * const kGothamBold = @"Gotham-Bold";
static NSString * const kGothamBoldItalic = @"Gotham-BoldItalic";
static NSString * const kGothamBook = @"Gotham-Book";
static NSString * const kGothamBookItalic = @"Gotham-BookItalic";
static NSString * const kGothamLight = @"Gotham-Light";
static NSString * const kGothamLightItalic = @"Gotham-LightItalic";
static NSString * const kGothamMedium = @"Gotham-Medium";
static NSString * const kGothamMediumItalic = @"Gotham-MediumItalic";
static NSString * const kGothamThin = @"Gotham-Thin";
static NSString * const kGothamThinItalic = @"Gotham-ThinItalic";
static NSString * const kGothamUltra = @"Gotham-Ultra";
static NSString * const kGothamUltraItalic = @"Gotham-UltraItalic";
static NSString * const kGothamXLight = @"Gotham-XLight";
static NSString * const kGothamXLightItalic = @"Gotham-XLightItalic";
static NSString * const kElegantIcons = @"ElegantIcons";

#endif
