//
//  STDomainCell.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 18/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STDomainCell : UITableViewCell

@property (nonatomic, readonly) UILabel *domainLabel;
@property (nonatomic, readonly) UILabel *statusLabel;
@property (nonatomic, readonly) UILabel *priceLabel;
@property (nonatomic, readonly) UILabel *expireLabel;
@property (nonatomic, readonly) UILabel *registeredLabel;
@property (nonatomic, readonly) UILabel *nextInvoiceLabel;

@end
