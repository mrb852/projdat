//
//  STButton.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STButton.h"

@implementation STButton

#pragma mark - Life Cycle

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if (self) {
		[self sharedInit];
	}
	return self;
}

- (void)awakeFromNib {
	[self sharedInit];
}

- (void)dealloc {
	self.buttonUpHandler = NULL;
	self.buttonDownHandler = NULL;
}

#pragma mark - Setup

/**
 * Initializes the button
 */

#pragma TO DO: change the font
- (void)sharedInit {
	// Set the default button colors
	self.normalBackgroundColor = [UIColor surftownBlue];
	self.selectedBackgroundColor = [[UIColor surftownBlue] colorWithAlphaComponent:.75];
	self.backgroundColor = self.normalBackgroundColor;

	self.layer.cornerRadius = 3.0;

	// Set up the text label.
	_textLabel = [[UILabel alloc] initWithFrame:self.bounds];
	[_textLabel setTextAlignment:NSTextAlignmentCenter];
	[_textLabel setAutoresizingMask:UIViewAutoresizingFlexibleHeight
	 | UIViewAutoresizingFlexibleWidth];
    [_textLabel setFont:[UIFont fontWithName:kGothamMedium size:16]];

	[_textLabel setTextColor:[UIColor whiteColor]];
	[self addSubview:_textLabel];
	self.text = @"Button";

	// Makes the button interactive.
	[self addTarget:self
	              action:@selector(buttonDown)
	    forControlEvents:UIControlEventTouchDown];

	[self addTarget:self
	              action:@selector(buttonUpInside)
	    forControlEvents:UIControlEventTouchUpInside];

	// TO DO: Make another callback.
	[self addTarget:self
	              action:@selector(buttonUpOutside)
	    forControlEvents:UIControlEventTouchUpOutside];
}

#pragma mark - Layout

/**
 * Layouts the subviews - needed for the text label.
 */
- (void)layoutSubviews {
	[super layoutSubviews];
	[self.textLabel setNeedsDisplay];
}

#pragma mark - Accessors

// Sets the labels text
- (void)setText:(NSString *)text {
	self.textLabel.text = text;
}

// Gets the labels text
- (NSString *)text {
	return self.textLabel.text;
}

#pragma mark - Button events

/**
 * Handles the button down event
 */
- (void)buttonDown
{
	self.backgroundColor = self.selectedBackgroundColor;
	// Trigger the buttons down event handler - if it's not null

    if (self.buttonDownHandler != NULL) {
        self.buttonDownHandler();
	}
}

/**
 * Handles the button up inside event
 */
- (void)buttonUpInside {
	self.backgroundColor = self.normalBackgroundColor;
	// Trigger the buttons up event handler - if it's not null
	if (self.buttonUpHandler != NULL) {
		self.buttonUpHandler();
	}
}

/**
 * Handles the button up outside event
 */
- (void)buttonUpOutside {
	self.backgroundColor = self.normalBackgroundColor;
}

@end
