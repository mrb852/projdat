//
//  STButton.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STButton : UIButton

/**
 * Displays the text in the button
 */
@property (nonatomic, strong, readonly) UILabel *textLabel;

/**
 * The buttons text
 */
@property (nonatomic, assign) NSString *text;

/**
 * The buttons color for the normal state
 */
@property (nonatomic, strong) UIColor *normalBackgroundColor;

/**
 * The buttons color for the selected state
 */
@property (nonatomic, strong) UIColor *selectedBackgroundColor;

/**
 * Callback function for the touch down event
 */
@property (nonatomic, copy) void (^buttonDownHandler) (void);

/**
 * Callback function for the touch down inside event
 */

@property (nonatomic, copy) void (^buttonUpHandler) (void);

@end
