//
//  STLoginViewController.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 15/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "STScrollViewController.h"
#import "HBUser.h"

@interface STLoginViewController : STScrollViewController <UITextFieldDelegate>

@end
