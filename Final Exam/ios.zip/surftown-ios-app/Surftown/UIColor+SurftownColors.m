//
//  UIColor+SurftownColors.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "UIColor+SurftownColors.h"

@implementation UIColor (SurftownColors)

+ (UIColor *)surftownGray {
    return [UIColor colorWithRed:55.0/255.0 green:55.0/255.0 blue:54.0/255.0 alpha:1.0];
}

+ (UIColor *)surftownPurple {
    return [UIColor colorWithRed:112.0/255.0 green:34.0/255.0 blue:126.0/255.0 alpha:1.0];
}

+ (UIColor *)surftownBlue {

    return  [UIColor colorWithRed:36.0/255.0 green:156.0/255.0 blue:220.0/255.0 alpha:1.0];
}

+ (UIColor *)surftownGreen {
    return [UIColor colorWithRed:39.0/255.0 green:174.0/255.0 blue:96.0/255.0 alpha:1.0];
}

+ (UIColor *)surftownLightGreen {
    return [UIColor colorWithRed:46.0/255.0 green:204.0/255.0 blue:113.0/255.0 alpha:1.0];
}

+ (UIColor *)surftownPlaceholderTextColor {
    return [UIColor colorWithRed:119.0/255.0 green:126.0/255.0 blue:135.0/255.0 alpha:1.0];
}

@end
