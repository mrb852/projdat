//
//  STDomainViewController.m
//  Surftown
//
//  Created by Simon Warg on 15/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STDomainViewController.h"
#import "HBDomain.h"
#import "STDomainCell.h"

@interface STDomainViewController ()

@property (nonatomic) NSArray* domains;
@property (nonatomic) UIColor *statusColorActive;
@property (nonatomic) UIColor *statusColorError;

@end

@implementation STDomainViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        [self sharedInit];
        [[self tableView] registerClass:[STDomainCell class] forCellReuseIdentifier:@"cell"];
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        [self sharedInit];
    }
    return self;
}

- (void)sharedInit
{
    self.statusColorActive = [UIColor colorWithRed:0.153 green:0.682 blue:0.376 alpha:1.000];
    self.statusColorError = [UIColor colorWithRed:0.906 green:0.298 blue:0.235 alpha:1.000];
    [self.tableView registerClass:[STDomainCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView setBackgroundView:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ServerBackground"]]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _domains = [HBDomain domainsFromAPI];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _domains.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 136;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STDomainCell *cell = (STDomainCell *)[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];

    HBDomain *domain = self.domains[indexPath.row];

    cell.domainLabel.text = domain.domainName;
    cell.statusLabel.text = domain.domainStatus;
    cell.priceLabel.text = domain.domainPrice;
    cell.expireLabel.text = domain.domainExpire;

    if ([domain.domainStatus.lowercaseString isEqualToString:@"active"]) {
        cell.statusLabel.textColor = self.statusColorActive;
    } else {
        cell.statusLabel.textColor = self.statusColorError;
    }
    
    return cell;
}

@end
