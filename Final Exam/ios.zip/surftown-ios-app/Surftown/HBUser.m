//
//  HBUser.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "HBUser.h"
#import "HBRequest.h"

static HBUser *_currentUser;

@interface HBUser()
@property (nonatomic) NSDictionary *details;
@property (nonatomic) BOOL authenticated;
@end

@implementation HBUser

+ (instancetype)currentUser {
    return _currentUser;
}

+ (instancetype)loginWithEmail:(NSString *)email password:(NSString *)password
{
    HBUser *user = [[HBUser alloc] init];

    [HBRequest authenticateUserWithEmail:email password:password completion:^(NSDictionary *response, NSError *error, BOOL success) {
        if (success) {
            [HBRequest getRequestWithCall:@"/client" completion:^(NSDictionary *response, NSError *error, BOOL success) {
                if (success) {
                    [user setupProperties:[response objectForKey:@"client"]];
                }
            }];
            user.authenticated = YES;
            _currentUser = user;
        }

    }];
    //    [HBRequest postRequestWithCall:@"/client/verify" details:details completion:^(NSDictionary *response, NSError *error, BOOL success) {
    //        if (success) {
    //            [HBRequest getRequestWithCall:@"/client" completion:^(NSDictionary *response, NSError *error, BOOL success) {
    //                if (success) {
    //                    [user setupProperties:[response objectForKey:@"client"]];
    //                }
    //            }];
    //            user.authenticated = YES;
    //            _currentUser = user;
    //        }
    //    }];
    return user;
}

- (void)setupProperties:(NSDictionary *)clientDetails
{
    self.client_id =            [[clientDetails objectForKey:@"client_id"] intValue];
    self.email =                [clientDetails objectForKey:@"email"];
    self.password =             [clientDetails objectForKey:@"password"];
    self.lastlogin =            [clientDetails objectForKey:@"lastlogin"];
    self.ip =                   [clientDetails objectForKey:@"ip"];
    self.host =                 [clientDetails objectForKey:@"host"];
    self.status =               [clientDetails objectForKey:@"status"];
    self.parent_id =            [[clientDetails objectForKey:@"parent_id"] intValue];
    self.firstname =            [clientDetails objectForKey:@"firstname"];
    self.lastname =             [clientDetails objectForKey:@"lastname"];
    self.companyname =          [clientDetails objectForKey:@"companyname"];
    self.address1 =             [clientDetails objectForKey:@"address1"];
    self.address2 =             [clientDetails objectForKey:@"address2"];
    self.city =                 [clientDetails objectForKey:@"city"];
    self.state =                [clientDetails objectForKey:@"state"];
    self.postcode =             [clientDetails objectForKey:@"postcode"];
    self.country =              [clientDetails objectForKey:@"country"];
    self.phonenumber =          [clientDetails objectForKey:@"phonenumber"];
    self.datecreated =          [clientDetails objectForKey:@"datecreated"];
    self.notes =                [clientDetails objectForKey:@"notes"];
    self.language =             [clientDetails objectForKey:@"language"];
    self.company =              [clientDetails objectForKey:@"company"];
    self.credit =               [[clientDetails objectForKey:@"credit"] floatValue];
    self.taxexempt =            [[clientDetails objectForKey:@"taxexempt"] boolValue];
    self.latefeeoveride =       [[clientDetails objectForKey:@"latefeeoveride"] boolValue];
    self.expdate            =   [clientDetails objectForKey:@"expdate"];
    self.overideduenotices  =   [[clientDetails objectForKey:@"overideduenotices"] boolValue];
    self.currency_id =          [[clientDetails objectForKey:@"currency_id"] intValue];
    self.countryname =          [clientDetails objectForKey:@"countryname"];
}

@end
