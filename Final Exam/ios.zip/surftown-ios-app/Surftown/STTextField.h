//
//  STTextField.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STTextField : UITextField

/**
 * The border color - Defaults to white.
 */
@property (nonatomic, strong) UIColor *borderColor;

@property (nonatomic) NSString *icon;
@property (nonatomic) CGFloat iconSize;

@end
