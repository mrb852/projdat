//
//  STAppDelegate.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STAppDelegate.h"
#import "STHomeViewController.h"
#import "STLoginViewController.h"
#import "HBUser.h"

static STAppDelegate *_sharedAppDelegate;

@implementation STAppDelegate

+ (instancetype)sharedAppDelegate
{
    return _sharedAppDelegate;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    _sharedAppDelegate = self;
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [self preloadKeyboard];

    // Init navigationController
    STLoginViewController *loginVC =[[STLoginViewController alloc] initWithNibName:nil
                                                                            bundle:nil];
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:loginVC];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new]
                             forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
    self.navigationController.navigationBar.translucent = YES;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.backgroundColor = [UIColor surftownBlue];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    self.window.rootViewController = self.navigationController;
    // Override point for customization after application launch.
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        self.addStatusBar = [[UIView alloc] init];
        self.addStatusBar.frame = CGRectMake(0, 0, 320, 20);
        self.addStatusBar.backgroundColor = [UIColor surftownBlue];
        [self.window.rootViewController.view addSubview:self.addStatusBar];
        self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
    }


    [self.window makeKeyAndVisible];

    UIImageView *splashView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Background"]];
    [self.window addSubview:splashView];
    [self.window bringSubviewToFront:splashView];

    [UIView animateWithDuration:.5 animations:^{
       splashView.alpha = 0.0;
    } completion:^(BOOL finished) {
       [splashView removeFromSuperview];

    }];
    return YES;
}

- (void)preloadKeyboard {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];

    // Preloads keyboard so there's no lag on initial keyboard appearance.
    UITextField *lagFreeField = [[UITextField alloc] init];
    [self.window addSubview:lagFreeField];
    [lagFreeField becomeFirstResponder];
    [lagFreeField resignFirstResponder];
    [lagFreeField removeFromSuperview];


}

- (void)keyboardWillShow:(NSNotification *)notification {
    NSDictionary* keyboardInfo = [notification userInfo];
    NSValue* keyboardFrameBegin = [keyboardInfo valueForKey:UIKeyboardFrameBeginUserInfoKey];
    _keyboardHeight = [keyboardFrameBegin CGRectValue].size.height;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
