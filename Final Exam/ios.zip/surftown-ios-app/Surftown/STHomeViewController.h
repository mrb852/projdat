//
//  STDashboardViewController.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STScrollViewController.h"

@interface STHomeViewController : STScrollViewController <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) UITableView *tableView;

@end
