//
//  HBUser.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <Foundation/Foundation.h>

@class HBRequest;

static BOOL HBUser_offlineMode = false;

@interface HBUser : NSObject

+ (instancetype)currentUser;

// Login
+ (instancetype)loginWithEmail:(NSString *)email password:(NSString *)password;

+ (void)loginInBackgroundWithEmail:(NSString *)email
                          password:(NSString *)password
                             block:(void (^)(HBUser* user, NSError* error))block;


// Properties

@property (nonatomic, readonly, getter=isAuthenticated) BOOL authenticated;

@property (nonatomic) NSString* email;
@property (nonatomic) NSString* password;
@property (nonatomic) NSDate* lastlogin;
@property (nonatomic) NSString* ip;
@property (nonatomic) NSString* host;
@property (nonatomic) NSString* status;
@property (nonatomic) int parent_id;
@property (nonatomic) NSString* firstname;
@property (nonatomic) NSString* lastname;
@property (nonatomic) NSString* companyname;
@property (nonatomic) NSString* address1;
@property (nonatomic) NSString* address2;
@property (nonatomic) NSString* city;
@property (nonatomic) NSString* state;
@property (nonatomic) NSString* postcode;
@property (nonatomic) NSString* country;
@property (nonatomic) NSString* phonenumber;
@property (nonatomic) NSDate* datecreated;
@property (nonatomic) NSString* notes;
@property (nonatomic) NSString* language;
@property (nonatomic) NSString* company;
@property (nonatomic) CGFloat credit;
@property (nonatomic) BOOL taxexempt;
@property (nonatomic) BOOL latefeeoveride;
@property (nonatomic) NSDate* expdate;
@property (nonatomic) BOOL overideduenotices;
@property (nonatomic) int client_id;
@property (nonatomic) int currency_id;
@property (nonatomic) NSString* countryname;

@end
