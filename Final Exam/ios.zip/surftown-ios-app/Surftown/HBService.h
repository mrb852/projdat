//
//  HBService.h
//  Surftown
//
//  Created by Simon Warg on 06/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HBService : NSObject

+ (NSArray*)loadServices;

- (NSString*) serviceTypeAsString;

@property(nonatomic) NSString *serviceName;
@property(nonatomic, getter = serviceTypeAsString) NSString *serviceType;
@property(nonatomic) NSString *systemStatus;
@property(nonatomic) NSString *servicePrice;
@property(nonatomic) NSString *serviceCurrencySign;
@property(nonatomic) NSString *serviceNextDue;
@property(nonatomic) NSString *serviceNextInvoice;
@property(nonatomic) NSString *serviceID;

@end
