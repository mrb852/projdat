//
//  STServiceCell.m
//  Surftown
//
//  Created by Simon Warg on 21/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STServiceCell.h"

@interface STServiceCell()
@property(nonatomic) int nbrCellElements;
@property(nonatomic) UILabel* cellTitleLabel;
@property(nonatomic) UIView* cellBorder;
@property (nonatomic) CAShapeLayer *seperationLine;
@end

@implementation STServiceCell


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:.2];
    }
    return self;
}



@end
