//
//  STLoginViewController.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 15/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STLoginViewController.h"
#import "STTextField.h"
#import "STButton.h"
#import "STAppDelegate.h"
#import "STHomeViewController.h"
#import "STServiceViewController.h"
#import "HBService.h"

@interface STLoginViewController () <UIAlertViewDelegate>

// The username text field
@property (nonatomic, strong) STTextField *usernameTextField;

// The password text field
@property (nonatomic, strong) STTextField *passwordTextField;

// The submit button
@property (nonatomic, strong) STButton *loginButton;

@property (nonatomic, strong) STButton *forgotPasswordButton;

@end

@implementation STLoginViewController



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
	self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
	if (self) {
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];

    self.navigationController.navigationBarHidden = YES;
    [STAppDelegate sharedAppDelegate].addStatusBar.backgroundColor = [UIColor clearColor];
    if ([STAppDelegate sharedAppDelegate]) {
        NSLog(@"2fdsa");
    }
	// ------------------------------------
	// SETUP SUB VIEWS
	// ------------------------------------
	CGSize viewSize = self.view.frame.size;

	UIImage *image = [UIImage imageNamed:@"Surftown_logo_rgb"];
	UIImageView *surftownLogo = [[UIImageView alloc] initWithImage:image];
	[surftownLogo setContentMode:UIViewContentModeScaleAspectFit];
	[self.scrollView addSubview:surftownLogo];

	CGRect frame = surftownLogo.frame;
	frame.size = CGSizeMake(viewSize.width, viewSize.height * .105);
	frame.origin = CGPointMake(viewSize.width / 2.03 - frame.size.width / 2, viewSize.height * .08);
	surftownLogo.frame = frame;

	// Setup the username textfield.
	frame = CGRectMake(viewSize.width * 0.05, // x
	                   viewSize.height * .3,        // y
	                   viewSize.width - (viewSize.width * 0.10),        // width
	                   44);        // height

	self.usernameTextField = [[STTextField alloc] initWithFrame:frame];
	self.usernameTextField.placeholder = @"Username";
    self.usernameTextField.text = @"ctl@surftown.dk";
	self.usernameTextField.keyboardType = UIKeyboardTypeEmailAddress;
	self.usernameTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
	self.usernameTextField.autocorrectionType = UITextAutocorrectionTypeNo;
	self.usernameTextField.returnKeyType = UIReturnKeyNext;
    self.usernameTextField.icon = kIconProfile;

	// Setup the password textfield. Reuse the frame for less code.
	frame.origin.y += frame.size.height + (viewSize.height * .03);
	self.passwordTextField = [[STTextField alloc] initWithFrame:frame];
	self.passwordTextField.placeholder = @"Password";
    self.passwordTextField.text = @"123";
	self.passwordTextField.autocorrectionType = UITextAutocorrectionTypeNo;
	self.passwordTextField.returnKeyType = UIReturnKeyDone;
    self.passwordTextField.icon = kIconLockAlt;

	// Makes sure that the password is not visible
	self.passwordTextField.secureTextEntry = YES;

    	frame.origin.y += frame.size.height + (viewSize.height * .008);

    self.forgotPasswordButton = [[STButton alloc] initWithFrame:frame];
	self.forgotPasswordButton.text = @"Forgot your password?";
    NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:@"Forgot password?" attributes:@{NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle)}];
    self.forgotPasswordButton.textLabel.attributedText = attributedText;
	self.forgotPasswordButton.backgroundColor = [UIColor clearColor];
	self.forgotPasswordButton.selectedBackgroundColor = [UIColor clearColor];
	self.forgotPasswordButton.normalBackgroundColor = [UIColor clearColor];

	self.forgotPasswordButton.textLabel.font = [UIFont fontWithName:kGothamMedium size:12];
	self.forgotPasswordButton.textLabel.textColor = [UIColor surftownPlaceholderTextColor];
	[self.scrollView addSubview:self.forgotPasswordButton];


	// Setup the submit/login button
	frame.origin.y += frame.size.height + (viewSize.height * .008);
	self.loginButton = [[STButton alloc] initWithFrame:frame];
	self.loginButton.text = @"LOGIN";

	// Set button handler
	[self setupButtonHandlers];

	// set delegates
	self.usernameTextField.delegate = self;
	self.passwordTextField.delegate = self;


	__unsafe_unretained STButton *weakBtn = _forgotPasswordButton;
	[self.forgotPasswordButton setButtonUpHandler: ^{
	    [weakBtn.textLabel setTextColor:[weakBtn.textLabel.textColor colorWithAlphaComponent:1.0]];
	}];

	[self.forgotPasswordButton setButtonDownHandler: ^{
	    [weakBtn.textLabel setTextColor:[weakBtn.textLabel.textColor colorWithAlphaComponent:.5]];
	}];

	// Add the subviews
	[self.scrollView addSubview:self.usernameTextField];
	[self.scrollView addSubview:self.passwordTextField];
	[self.scrollView addSubview:self.loginButton];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [STAppDelegate sharedAppDelegate].addStatusBar.backgroundColor = [UIColor surftownBlue];
}

/**
 *  Makes password field the next responder if it's not already the first responder.
 *  Otherwise it resigns as the first responder
 *  @param textField the textfield that is currently the first responder
 *  @return always YES
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	if (textField == self.usernameTextField) {
		[self.passwordTextField becomeFirstResponder];
	}
	else {
		[textField resignFirstResponder];
	}
	return YES;
}

#pragma mark TO DO: Login to hostbill
- (void)setupButtonHandlers
{
    __unsafe_unretained STLoginViewController* weakSelf = self;
	[self.loginButton setButtonUpHandler: ^
    {
	    // Log in to host bill, only if we are online
        HBUser* user;
        if(!HBUser_offlineMode) {
            NSString *email = weakSelf.usernameTextField.text;
            NSString *password = weakSelf.passwordTextField.text;
            user = [HBUser loginWithEmail:email password:password];
        }
    
        if (user.isAuthenticated | HBUser_offlineMode) {
            [weakSelf hbUserDidAuthenticate];
            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Fatal Error"
                                                            message:@"Failed to login"
                                                           delegate:weakSelf
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
        }
        
	}];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
}

- (void)hbUserDidAuthenticate {
//    STDashboardViewController *dashBoard = [[STDashboardViewController alloc] initWithNibName:nil bundle:nil];
//    NSArray *services = [HBService loadServices];
//    if (services.count > 0) {
//        HBService *service = [services objectAtIndex:0];
//        if (service) {
//            NSLog(@"%@", service.systemType);
//        }
//
//    }
    
//    STServiceViewController *serviceView = [[STServiceViewController alloc] initWithNibName:nil bundle:nil];
    STHomeViewController *dashBoard = [[STHomeViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:dashBoard animated:YES];
}

@end
