//
//  HBRequest.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "HBRequest.h"
#import <RestKit/RestKit.h>

static NSString *baseRequestUrl = @"http://127.0.0.1:1337";


@implementation HBRequest

+ (void)postRequestWithCall:(NSString *)call details:(NSDictionary *)details completion:(HBRequestCompletion)completion
{
    NSURL *baseURL = [NSURL URLWithString:baseRequestUrl];
    RKObjectManager *objectManager = [RKObjectManager managerWithBaseURL:baseURL];
    NSMutableURLRequest *request   = [objectManager requestWithObject:nil
                                                               method:RKRequestMethodPOST
                                                                 path:call
                                                           parameters:details];
    NSURLResponse *response;
    NSData *data = [NSURLConnection sendSynchronousRequest:request
                                         returningResponse:&response
                                                     error:nil];
    NSError *error = nil;
    NSDictionary *result = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    completion(result, error, [[result objectForKey:@"success"] boolValue]);

}

+ (void)getRequestWithCall:(NSString *)call completion:(HBRequestCompletion)completion
{
    NSURL *baseURL = [NSURL URLWithString:baseRequestUrl];
    RKObjectManager *objectManager = [RKObjectManager managerWithBaseURL:baseURL];
    NSMutableURLRequest *request   = [objectManager requestWithObject:nil
                                                               method:RKRequestMethodGET
                                                                 path:call
                                                           parameters:nil];
    NSURLResponse *response;
    NSData *data = [NSURLConnection sendSynchronousRequest:request
                                         returningResponse:&response
                                                     error:nil];
    NSError *error = nil;
    NSDictionary *result = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    completion(result, error, [[result objectForKey:@"success"] boolValue]);

}

+ (void)authenticateUserWithEmail:(NSString *)email password:(NSString *)password completion:(HBRequestCompletion)completion
{
    NSURL *baseURL = [NSURL URLWithString:baseRequestUrl];
    AFHTTPClient * client = [AFHTTPClient clientWithBaseURL:baseURL];
    [client setDefaultHeader:@"Accept" value:RKMIMETypeJSON];
    [client setAuthorizationHeaderWithUsername:email password:password];
    RKObjectManager *objectManager = [[RKObjectManager alloc] initWithHTTPClient:client];

    NSURLRequest *request = [objectManager requestWithObject:nil method:RKRequestMethodGET path:@"/client/verify" parameters:nil];
    NSURLResponse *response;
    NSError *error;
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];

    completion(dict, error, [[dict objectForKey:@"success"] boolValue]);
    
}


@end
