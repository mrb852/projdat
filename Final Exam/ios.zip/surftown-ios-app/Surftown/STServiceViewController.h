//
//  STServiceViewController.h
//  Surftown
//
//  Created by Simon Warg on 06/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STScrollViewController.h"

@interface STServiceViewController : STScrollViewController <UITableViewDataSource, UITableViewDelegate>

@property NSArray *services;
@property (nonatomic) UITableView *tableView;

@end
