//
//  HBRequest.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^HBRequestCompletion)(NSDictionary *response, NSError* error, BOOL success);

@interface HBRequest : NSObject <NSURLConnectionDelegate>

+ (void)postRequestWithCall:(NSString *)call details:(NSDictionary *)details completion:(HBRequestCompletion)completion;
+ (void)getRequestWithCall:(NSString *)call completion:(HBRequestCompletion)completion;
+ (void)authenticateUserWithEmail:(NSString *)email password:(NSString *)password completion:(HBRequestCompletion)completion;

@end
