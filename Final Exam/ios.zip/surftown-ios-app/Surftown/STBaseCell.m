//
//  STBaseCell.m
//  Surftown
//
//  Created by Simon Warg on 21/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STBaseCell.h"

@interface STBaseCell()

@property(nonatomic) int nbrCellElements;
@property(nonatomic) UILabel* cellTitleLabel;
@property (nonatomic) CAShapeLayer *seperationLine;

@end

static int cellElementHeight = 32;

@implementation STBaseCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self sharedInit];
        self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:.5];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self sharedInit];
    }
    return self;
}


- (void)sharedInit
{
    self.nbrCellElements = 0;
    
    
    self.seperationLine = [CAShapeLayer layer];
    self.seperationLine.lineCap = kCALineCapRound;
    self.seperationLine.strokeColor = [[UIColor surftownGray] colorWithAlphaComponent:0.1].CGColor;
    self.seperationLine.lineWidth = 2;
    [self.layer addSublayer:self.seperationLine];
}

- (void)layoutSubviews
{
    CGRect separatorFrame = CGRectMake(16, 0, self.frame.size.width-16, self.frame.size.height);
    
    [super layoutSubviews];
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathMoveToPoint(path, NULL, 16, CGRectGetHeight(self.frame) - .5);
    CGPathAddLineToPoint(path, NULL, CGRectGetWidth(separatorFrame), CGRectGetHeight(self.frame) - .5);
    self.seperationLine.path = path;
    CGPathRelease(path);
}

// Adds a caption/text pair onto the cell
// Example Caption:Expires, Text:2009-09-10
- (void)addCaption:(NSString*)caption withText:(NSString*)text {

    CGRect viewFrame = self.frame;
    
    // labelSpace is y-space between the pair
    // cellMargin is a traling space after each cell
    CGFloat x, y, w, h, labelSpace, cellMargin;
    
    x = 16;
    y = 38;
    w = viewFrame.size.width/2;
    h = cellElementHeight/2;
    labelSpace = 16;
    cellMargin = 24;
    
    UIFont *fontCaption = [UIFont fontWithName:kGothamMedium size:16];
    UIFont *fontText = [UIFont fontWithName:kGothamMedium size:14];
    
    // Push every other pair to the right for a two-column layout
    if(_nbrCellElements % 2) {
        x += w;
        y += (_nbrCellElements-1) * cellMargin;
    }
    else {
        y += _nbrCellElements * cellMargin;
    }
    
    CGRect frame = CGRectMake(x, y, w, h);
    CGRect frameText = CGRectMake(x, y+labelSpace, w, h);
    
    UILabel *captionLabel, *textLabel;
    captionLabel = [[UILabel alloc] initWithFrame:frame];
    
    captionLabel.font = fontCaption;
    captionLabel.textColor = textLabel.textColor = [UIColor surftownGray];
    captionLabel.text = caption;
    
    textLabel = [[UILabel alloc] initWithFrame:frameText];
    textLabel.text = text;
    textLabel.font = fontText;
    
    [self.contentView addSubview:captionLabel];
    [self.contentView addSubview:textLabel];
    
    // Count how many pairs we add
    _nbrCellElements++;
}

- (void)setCellTitleTo:(NSString*)title {
    CGRect viewFrame = self.frame;
    
    UIFont *font = [UIFont fontWithName:kGothamMedium size:20];
    UIColor *color = [UIColor surftownPurple];
    
    CGFloat leftX = 16;
    
    CGRect frame = CGRectMake(leftX, 8, viewFrame.size.width - 32, 24);
    
    self.cellTitleLabel = [[UILabel alloc] initWithFrame:frame];
    self.cellTitleLabel.font = font;
    self.cellTitleLabel.textColor = color;
    self.cellTitleLabel.adjustsFontSizeToFitWidth = YES;
    self.cellTitleLabel.text = title;
    [self.contentView addSubview:self.cellTitleLabel];
    
}

@end
