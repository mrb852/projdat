//
//  STHomeCell.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 18/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STHomeCell.h"

@interface STHomeCell()

@property (nonatomic) UILabel *iconLabel;

@end

@implementation STHomeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.iconLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 62, self.frame.size.height)];
        self.iconSize = 24.0;
        self.iconLabel.font = [UIFont fontWithName:kElegantIcons size:self.iconSize];
        self.iconLabel.textAlignment = NSTextAlignmentCenter;
        self.iconLabel.textColor = [UIColor colorWithWhite:.4 alpha:1.0];
        [self.contentView addSubview:_iconLabel];
    }
    return self;
}

- (void)setIcon:(NSString *)icon
{
    if (![_icon isEqualToString:icon]) {
        _icon = icon;
        self.iconLabel.text = icon;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.textLabel.frame = CGRectMake(62, 0, self.frame.size.width-62, self.frame.size.height);
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

}

@end
