//
//  UIColor+SurftownColors.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (SurftownColors)

+ (UIColor *)surftownGray;
+ (UIColor *)surftownPurple;
+ (UIColor *)surftownBlue;
+ (UIColor *)surftownGreen;
+ (UIColor *)surftownLightGreen;
+ (UIColor *)surftownPlaceholderTextColor;

@end
