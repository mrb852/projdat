//
//  STTextField.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STTextField.h"
#import <QuartzCore/QuartzCore.h>

@implementation STTextField {
    BOOL drawsIcon;
    UILabel *iconLabel;
    CAGradientLayer *gradient;
}

- (id)initWithFrame:(CGRect)frame {

    self = [super initWithFrame:frame];
    if (self) {
        [self sharedInit];
    }
    return self;
}

- (void)awakeFromNib {
    [self sharedInit];
}

- (void)sharedInit {

    // Setup the look
    self.backgroundColor = [UIColor clearColor];
    self.borderColor = [UIColor colorWithWhite:.35 alpha:1.0];
    self.borderStyle = UITextBorderStyleNone;
    self.layer.borderWidth = .5;
    self.layer.borderColor = self.borderColor.CGColor;
    self.layer.cornerRadius = 2;
    [self setTextColor:[UIColor colorWithWhite:.35 alpha:1.0]];

    self.font = [UIFont fontWithName:kGothamBook size:16];
    self.iconSize = 24;
    iconLabel = [[UILabel alloc] initWithFrame:self.frame];
    iconLabel.font = [UIFont fontWithName:kElegantIcons size:self.iconSize];
    iconLabel.textColor = self.textColor;
    iconLabel.textAlignment = NSTextAlignmentCenter;
    iconLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:iconLabel];
    self.icon = kIconLockAlt;
    
    // Default placeholder
    self.placeholder = @"Placeholder";

    gradient = [CAGradientLayer layer];
    gradient.frame = CGRectMake(self.frame.size.height, 0, self.frame.size.width-self.frame.size.height, self.frame.size.height);
    gradient.colors = @[(id)[UIColor colorWithWhite:1.0 alpha:.1].CGColor, (id)[UIColor colorWithWhite:1.0 alpha:.7].CGColor];
    gradient.locations = @[@(0.0), @(1.0)];
    [self.layer addSublayer:gradient];
}

- (CGRect)textDrawingBounds:(CGRect)bounds
{
    if (drawsIcon) {
        return CGRectInset(bounds, self.frame.size.height + 6, 0);
    }
    return CGRectInset(bounds, 12, 0);

}

- (CGRect)textRectForBounds:(CGRect)bounds {
    return [self textDrawingBounds:bounds];
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    return [self textDrawingBounds:bounds];
}

- (void)setPlaceholder:(NSString *)placeholder {
    [super setPlaceholder:placeholder];

    if ([self respondsToSelector:@selector(setAttributedPlaceholder:)]) {

        UIColor *color = [UIColor surftownPlaceholderTextColor];
        self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.placeholder
                                                                     attributes:@{NSForegroundColorAttributeName: color}];
    }

}

- (void)setIcon:(NSString *)icon
{
    if (![_icon isEqualToString:icon]) {
        _icon = icon;
        iconLabel.text = _icon;
        //To Do : convert to one liner
        if ([_icon isEqualToString:@""] || !_icon) {
            drawsIcon = NO;
        } else {
            drawsIcon = YES;
            [self setNeedsDisplay];
        }
        iconLabel.hidden = !drawsIcon;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    iconLabel.frame = CGRectMake(0, 0, self.frame.size.height-1, self.frame.size.height-1);
    gradient.frame = CGRectMake(self.frame.size.height, 0, self.frame.size.width - self.frame.size.height, self.frame.size.height);
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];

    if (drawsIcon)
    {
        CGRect frame = CGRectMake(0, 0, rect.size.height-1, rect.size.height-1);
        CGContextRef context = UIGraphicsGetCurrentContext();
        [[UIColor colorWithWhite:1.0 alpha:.55] setFill];
        CGContextFillRect(context, frame);
        frame.origin.x = frame.size.width;
        frame.size.width = .5;
        [[UIColor colorWithCGColor:self.layer.borderColor] setFill];
        CGContextFillRect(context, frame);

    }
}

@end
