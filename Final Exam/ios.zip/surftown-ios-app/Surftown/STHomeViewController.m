//
//  STDashboardViewController.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 29/04/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STHomeViewController.h"
#import "HBUser.h"
#import "STDomainViewController.h"
#import "STServiceViewController.h"
#import "STHomeCell.h"

@interface STHomeViewController ()
@property (nonatomic, strong) UILabel *greetingsLabel;
@end

@implementation STHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self setEdgesForExtendedLayout:UIRectEdgeAll];
    CGRect tableViewFrame = self.view.frame;

    self.tableView = [[UITableView alloc] initWithFrame:tableViewFrame
                                                  style:UITableViewStylePlain];
    self.tableView.contentInset = UIEdgeInsetsMake(self.navigationController.navigationBar.frame.size.height + [[UIApplication sharedApplication] statusBarFrame].size.height , 0,0,0);
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[STHomeCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView setScrollEnabled:NO];
    self.tableView.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2);
    [self.scrollView addSubview:self.tableView];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    self.navigationController.navigationBarHidden = NO;
    self.navigationItem.title = @"Home";

    [self.navigationItem setHidesBackButton:YES animated:NO];

    HBUser *user = [HBUser currentUser];
    if (user.isAuthenticated) {

    }
}

#pragma mark - UITableViewDatasource / UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([HBUser currentUser] || HBUser_offlineMode) {
        return 5;
    }
    return 0;
}

-(void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([indexPath row] == ((NSIndexPath*)[[tableView indexPathsForVisibleRows] lastObject]).row){
        //end of loading
        //for example [activityIndicator stopAnimating];
        tableView.frame = CGRectMake(0, tableView.contentSize.height/2, self.view.frame.size.width, tableView.contentSize.height + tableView.contentSize.height/2);
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STHomeCell *cell = (STHomeCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"Services";
            cell.icon = kIconHouseAlt;
            CGRect frame = cell.iconLabel.frame;
            frame.origin.y -= 2;
            cell.iconLabel.frame = frame;
            break;
        case 1:
            cell.textLabel.text = @"Domains";
            cell.icon = kIconGlobe;
            frame = cell.iconLabel.frame;
            frame.origin.x -= 3;
            cell.iconLabel.frame = frame;
            break;
        case 2:
            cell.textLabel.text = @"Contact";
            cell.icon = kIconPhone;
            break;
        case 3:
            cell.textLabel.text = @"Support";
            cell.icon = kIconHeadphones;
            break;
        case 4:
            cell.textLabel.text = @"Status";
            cell.icon = kIconDrive;
            break;
        default:
            break;
    }
    cell.backgroundColor = [UIColor colorWithWhite:1.000 alpha:0.000];
    cell.textLabel.textColor = [UIColor surftownPurple];
    cell.textLabel.font = [UIFont fontWithName:kGothamBold size:18];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 0: {
            STServiceViewController *svController = [[STServiceViewController alloc] initWithNibName:nil
                                                                                              bundle:nil];
            [self.navigationController pushViewController:svController animated:YES];
        } break;
            
        case 1: {
            STDomainViewController *dvController = [[STDomainViewController alloc] initWithNibName:nil
                                                                                              bundle:nil];
            [self.navigationController pushViewController:dvController animated:YES];
        } break;

        default:
            break;
    }
}

@end
