//
//  STDomainCell.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 18/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STDomainCell.h"

@interface STDomainCell()

@property (nonatomic) UILabel *priceCaptionLabel;
@property (nonatomic) UILabel *expireCaptionLabel;
@property (nonatomic) UILabel *registeredCaptionLabel;
@property (nonatomic) UILabel *nextInvoiceCaptionLabel;
@property (nonatomic) UILabel *domainLabel;
@property (nonatomic) UILabel *statusLabel;
@property (nonatomic) UILabel *priceLabel;
@property (nonatomic) UILabel *expireLabel;
@property (nonatomic) UILabel *registeredLabel;
@property (nonatomic) UILabel *nextInvoiceLabel;

@end

@implementation STDomainCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        CGRect viewFrame = self.frame;

        UIFont *detailFont = [UIFont fontWithName:kGothamMedium size:12];
        UIFont *domainFont = [UIFont fontWithName:kGothamMedium size:20];

        UIColor *domainColor = [UIColor surftownPurple];

        CGFloat leftX = 16;
        CGFloat width = (viewFrame.size.width / 2) - leftX;

        CGRect frame = CGRectMake(leftX, 8, viewFrame.size.width - 32, 16);

        self.domainLabel = [[UILabel alloc] initWithFrame:frame];
        self.domainLabel.font = domainFont;
        self.domainLabel.textColor = domainColor;
        self.domainLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:self.domainLabel];

        frame.origin.y = frame.origin.y + frame.size.height;
        
        frame.size.height = 12;
        self.statusLabel = [[UILabel alloc] initWithFrame:frame];
        self.statusLabel.font = detailFont;
        self.statusLabel.textColor = [UIColor colorWithRed:0.153 green:0.682 blue:0.376 alpha:1.000];
        self.statusLabel.text = @"waiting..";
        [self.contentView addSubview:self.statusLabel];

        frame.origin.y = frame.origin.y + frame.size.height + 8;
        frame.size.height = 16;

        CGRect detailFrame = frame;
        detailFrame.size.width = width;
        detailFrame.origin.y += 14;

        self.priceCaptionLabel = [self createCaptionLabelWithFrame:frame];
        self.priceCaptionLabel.text = @"Price";
        self.priceLabel = [self createDetailLabelWithFrame:detailFrame];

        frame.origin.x = viewFrame.size.width/2;
        detailFrame.origin.x = frame.origin.x;
        self.expireCaptionLabel = [self createCaptionLabelWithFrame:frame];
        self.expireCaptionLabel.text = @"Expires";
        self.expireLabel = [self createDetailLabelWithFrame:detailFrame];

        frame.origin.x = leftX;
        frame.origin.y += frame.size.height + 32;
        detailFrame.origin.x = leftX;
        detailFrame.origin.y = frame.origin.y + 14;

        self.registeredCaptionLabel = [self createCaptionLabelWithFrame:frame];
        self.registeredCaptionLabel.text = @"Expires";
        self.registeredLabel = [self createDetailLabelWithFrame:detailFrame];

        frame.origin.x = viewFrame.size.width/2;
        detailFrame.origin.x = frame.origin.x;
        self.nextInvoiceCaptionLabel = [self createCaptionLabelWithFrame:frame];
        self.nextInvoiceCaptionLabel.text = @"Next invoice";
        self.nextInvoiceLabel = [self createDetailLabelWithFrame:detailFrame];


        self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:.5];

    }
    return self;
}

- (UILabel *)createCaptionLabelWithFrame:(CGRect)frame
{
    UIColor *captionColor = [UIColor colorWithWhite:0.545 alpha:1.000];
    UIFont *captionFont = [UIFont fontWithName:kGothamBold size:14];

    UILabel *captionLabel = [[UILabel alloc] initWithFrame:frame];
    captionLabel.font = captionFont;
    captionLabel.textColor = captionColor;

    [self.contentView addSubview:captionLabel];

    return captionLabel;
}

- (UILabel *)createDetailLabelWithFrame:(CGRect)frame
{
    UIColor *detailColor = [UIColor colorWithWhite:0.271 alpha:1.000];
    UIFont *detailFont = [UIFont fontWithName:kGothamMedium size:12];

    UILabel *detailLabel = [[UILabel alloc] initWithFrame:frame];
    detailLabel.font = detailFont;
    detailLabel.textColor = detailColor;
    detailLabel.text = @"N/A";

    [self.contentView addSubview:detailLabel];

    return detailLabel;
}


@end
