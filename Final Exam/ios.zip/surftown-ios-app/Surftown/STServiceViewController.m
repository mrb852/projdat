//
//  STServiceViewController.m
//  Surftown
//
//  Created by Simon Warg on 06/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STServiceViewController.h"
#import "HBService.h"
#import "STServiceCell.h"

@interface STServiceViewController ()

@end

@implementation STServiceViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
//        [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlackTranslucent;
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.extendedLayoutIncludesOpaqueBars = YES;
    self.automaticallyAdjustsScrollViewInsets = YES;


    self.tableView = [[UITableView alloc] initWithFrame:self.view.frame
                                                  style:UITableViewStylePlain];
    [self.tableView registerClass:[STServiceCell class] forCellReuseIdentifier:@"cell"];
    _services = [HBService loadServices];
//   self.tableView.contentInset = UIEdgeInsetsMake(self.navigationController.navigationBar.frame.size.height + [[UIApplication sharedApplication] statusBarFrame].size.height , 0,0,0);
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.scrollView addSubview:self.tableView];
    self.navigationItem.title = @"Services";
    self.tableView.backgroundColor = [UIColor clearColor];

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
//{
//    UIView *tempView=[[UIView alloc]initWithFrame:CGRectMake(0,200,300,244)];
//    tempView.backgroundColor=[UIColor surftownGray];
//    
//    UILabel *tempLabel=[[UILabel alloc]initWithFrame:CGRectMake(4,0,300,22)];
//    tempLabel.backgroundColor=[UIColor clearColor];
//    tempLabel.textColor = [UIColor whiteColor]; //here you can change the text color of header.
//    tempLabel.font = [UIFont fontWithName:@"Helvetica" size:14];
//    tempLabel.font = [UIFont boldSystemFontOfSize:14];
//    tempLabel.text= [self tableView:tableView titleForHeaderInSection:section];
//    
//    [tempView addSubview:tempLabel];
//
//    return tempView;
//}

#pragma mark - Table view data source

//- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
//{
//    // Return the number of sections.
//
//    return 0;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 136;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
   return [_services count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    STServiceCell *cell = (STServiceCell*)[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];

    NSInteger serviceIdx = indexPath.row;
    HBService *service = _services[serviceIdx];
    
    cell.cellTitle = service.serviceName;
    [cell addCaption:@"Expires" withText:service.serviceNextDue];
    [cell addCaption:@"Yearly" withText:service.servicePrice];
    [cell addCaption:@"Next invoice" withText:service.serviceNextInvoice];
    [cell addCaption:@"Invoice Due" withText:@"1m 6days"];
    
    return cell;
}

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
