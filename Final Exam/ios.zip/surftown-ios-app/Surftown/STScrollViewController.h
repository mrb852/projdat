//
//  STScrollViewController.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 16/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STScrollViewController : UIViewController <UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;

@end
