//
//  STBaseCell.h
//  Surftown
//
//  Created by Simon Warg on 21/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STDomainCell.h"

@interface STBaseCell : UITableViewCell

@property(nonatomic, setter = setCellTitleTo:) NSString* cellTitle;

- (void)setCellTitleTo:(NSString*)title;
- (void)addCaption:(NSString*)caption withText:(NSString*)text;

@end
