//
//  STServiceCell.h
//  Surftown
//
//  Created by Simon Warg on 21/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STBaseCell.h"

@interface STServiceCell : STBaseCell

@property(nonatomic) UILabel *serviceNameLabel;
@property(nonatomic, getter = serviceTypeAsString) UILabel *serviceTypeLabel;
@property(nonatomic) UILabel *systemStatusLabel;
@property(nonatomic) UILabel *servicePriceLabel;
@property(nonatomic) UILabel *serviceCurrencySignLabel;
@property(nonatomic) UILabel *serviceNextDueLabel;
@property(nonatomic) UILabel *serviceNextInvoiceLabel;
@property(nonatomic) UILabel *serviceIDLabel;
@property(nonatomic) UILabel *serviceStatusLabel;

@end
