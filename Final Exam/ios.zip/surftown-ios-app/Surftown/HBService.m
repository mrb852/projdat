//
//  HBService.m
//  Surftown
//
//  Created by Simon Warg on 06/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "HBService.h"
#import "HBRequest.h"
#import "HBUser.h"

@interface HBService()

+ (BOOL) APIFetchRequired;

@end

static NSArray *_services = nil;

@implementation HBService

// Gonna implement this Simon?
+ (BOOL)APIFetchRequired {return true;}



+ (NSArray *)loadServices {
    if (!_services) {
        __block NSMutableArray *services = [NSMutableArray array];
        NSString* call = @"/client/accounts";
        [HBRequest getRequestWithCall:call completion:^(NSDictionary *response, NSError *error, BOOL success) {
            if (success)  {
                NSArray *products = response[@"accounts"];
                if(products.count > 0) {
                    [products enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                        if ([obj isKindOfClass:[NSDictionary class]]) {
                            HBService *service = [[HBService alloc] initWithServiceData:(NSDictionary *)obj];
                            [services addObject:service];
                        } else {
                            NSLog(@"Fatal error");
                        }
                    }];
                }
                else {
                    NSLog(@"No services found");
                }
            }
            else {
                NSLog(@"The response was not successful");
            }
        }];
        _services = [[NSArray alloc] initWithArray:services];
    }

    return _services;
}



- (instancetype)initWithServiceData:(NSDictionary *)data
{
    self = [super init];
    if (self)
    {
        _serviceName = data[@"name"];
        _serviceID = data[@"id"];
        _serviceType = data[@"type"];
//        NSString *call = [NSString stringWithFormat:@""];
//        [HBRequest getRequestWithCall:call completion:^(NSDictionary *response, NSError *error, BOOL success) {
//                if(success) {
//                       NSDictionary *details = [response objectForKey:@"details"];
//                        if(details)
//                           {
//                          _serviceCurrencySign = details[@"currency"][@"sign"];
//                          _servicePrice = [NSString stringWithFormat:@"%@%@", details[@"total"], _serviceCurrencySign] ;
//                          _serviceNextDue = details[@"next_due"];
//                          _serviceNextInvoice = details[@"next_invoice"];
//                      }
//          }
//          }];
    }
    return self;
}

- (NSString*)serviceTypeAsString {
    NSString *type;
    switch([_serviceType intValue]) {
        case 0: type = @"Linux PHP/MySQL"; break;
        case 1: type = @"Windows .NET MSSQL"; break;
        default: type = @"TODO: Undefined";
    }
    return type;
}

@end
