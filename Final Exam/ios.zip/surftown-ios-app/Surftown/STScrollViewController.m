//
//  STScrollViewController.m
//  Surftown
//
//  Created by ChristianEnevoldsen on 16/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "STScrollViewController.h"
#import "STAppDelegate.h"

@implementation UIScrollView (Touches)

// init(string nibName, string bundle)

//- (UIView*)hitTest:(CGPoint)point withEvent:(UIEvent *)event
//{
//
//    UIView *result = [super hitTest:point withEvent:event];
//
//    if (result.superview == self) {
//        self.scrollEnabled = NO;
//        return result;
//    } else {
//        self.scrollEnabled = YES;
//    }
//    return result;
//
//}
//
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//    [self.superview touchesBegan:touches withEvent:event];
//}

@end

@interface STScrollViewController ()

@end

@implementation STScrollViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.view.frame];
    [self.view addSubview:[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ServerBackground"]]];
    [self.view addSubview:self.scrollView];
}

- (void)viewDidAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldBeganEdit:) name:UITextFieldTextDidBeginEditingNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textFieldEndedEdit:) name:UITextFieldTextDidEndEditingNotification object:nil];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)textFieldBeganEdit:(NSNotification *)notification {
    for (UIView *responder in self.scrollView.subviews) {
        if ([responder isFirstResponder]) {
            CGRect rect = [responder bounds];
            rect = [responder convertRect:rect toView:self.view];
            CGPoint point = rect.origin;
            point.x = 0;
            CGFloat padding = self.view.frame.size.height * .03;
            point.y = responder.frame.origin.y - ((STAppDelegate *)[UIApplication sharedApplication].delegate).keyboardHeight + padding;

            if (point.y > 0)
                [self.scrollView setContentOffset:point animated:YES];

            break;
        }
    }
}

- (void)textFieldEndedEdit:(NSNotification * )notification {
    [self.scrollView setContentOffset:CGPointZero animated:YES];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

@end
