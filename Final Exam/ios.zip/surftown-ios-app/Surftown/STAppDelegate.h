//
//  STAppDelegate.h
//  Surftown
//
//  Created by ChristianEnevoldsen on 14/03/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, readonly, assign) CGFloat keyboardHeight;
@property (nonatomic) UINavigationController *navigationController;
@property (nonatomic) UIView *addStatusBar;

+ (instancetype)sharedAppDelegate;

@end
