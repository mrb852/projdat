//
//  HBDomain.h
//  Surftown
//
//  Created by Simon Warg on 10/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HBDomain : NSObject

+ (NSArray*)domainsFromAPI;


@property (nonatomic) NSString *domainName;
@property(nonatomic, getter = status) NSString *domainStatus;
@property(nonatomic) NSString *domainRegistrar;
@property(nonatomic) NSString *domainExpire;
@property(nonatomic) NSString *domainNextDue;
@property(nonatomic) NSString *domainPrice;

@end
