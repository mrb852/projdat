//
//  HBDomain.m
//  Surftown
//
//  Created by Simon Warg on 10/05/14.
//  Copyright (c) 2014 Surftown. All rights reserved.
//

#import "HBDomain.h"
#import "HBUser.h"
#import "HBRequest.h"

@interface HBDomain()

@end

static NSArray* _domains = nil;

@implementation HBDomain

- (NSString*)status {
    if([_domainStatus isEqualToString:@"External"]) {
        return @"Active";
    }
    return _domainStatus;
}

+ (NSArray*)domainsFromAPI
{
    if(!_domains) {
        __block NSMutableArray* collectedDomains = [NSMutableArray array];

        NSString *call = [NSString stringWithFormat:@"client/domains"];
        [HBRequest getRequestWithCall:call completion:^(NSDictionary *response, NSError *error, BOOL success) {
            if(success) {
                NSLog(@"GOT IT!");
                NSArray *fetchedDomains = [response objectForKey:@"domains"];
                [fetchedDomains enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                    if([obj isKindOfClass:[NSDictionary class]]) {
                        HBDomain *domain = [[HBDomain alloc] initWithDomainDictData:(NSDictionary*)obj];
                        [collectedDomains addObject: domain];
                    }
                }];
            }

        }];
        _domains = [[NSArray alloc] initWithArray:collectedDomains];
    }
    return _domains;
}

-(instancetype) initWithDomainDictData:data {
    _domainName = data[@"name"];
    _domainPrice = @"99"; //data[@"recurring_amount"];
    _domainStatus = data[@"status"];
    _domainRegistrar = @"Surftown"; //data[@"type"];
    _domainExpire = data[@"expires"];
    _domainNextDue = data[@"next_due"];
    return self;
}

@end
